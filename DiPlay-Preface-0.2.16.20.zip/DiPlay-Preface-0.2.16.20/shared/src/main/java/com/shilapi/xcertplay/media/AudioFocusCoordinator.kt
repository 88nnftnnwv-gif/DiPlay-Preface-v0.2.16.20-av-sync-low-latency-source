// carlito | One focus owner for media, guidance, calls and Siri, including microphone-only phases.
package com.shilapi.xcertplay.media

import com.shilapi.xcertplay.compat.systemService
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.io.Closeable

internal class AudioFocusCoordinator(
    context: Context?,
    private val enabled: Boolean,
    private val report: (String) -> Unit = {},
    private val factoryRouting: Boolean = false,
    private val onOwnershipChanged: (Boolean) -> Unit = {},
    private val isExternalCall: (() -> Boolean)? = null,
) : Closeable {
    private data class Entry(val channel: AudioChannel, val attributes: AudioAttributes)
    private val manager = context?.systemService(AudioManager::class.java, "audio")
    private val active = LinkedHashMap<AudioTrack, Entry>()
    private val captures = LinkedHashMap<AudioChannel, Entry>()
    private var request: AudioFocusRequest? = null
    private var legacyListener: AudioManager.OnAudioFocusChangeListener? = null
    private var legacyGain = AudioManager.AUDIOFOCUS_GAIN
    private var requestedChannel: AudioChannel? = null
    private var requestGeneration = 0
    private var focusHeld = false
    private var focusVolume = 0f
    private var mediaAttributes: AudioAttributes? = null
    private var mediaSuppressed = false
    private var mediaPlaying: Boolean? = null
    private var externalCall = false
    private var ownership: Boolean? = null
    private var closed = false

    @Synchronized private fun onFocusChanged(generation: Int, change: Int) {
        if (closed || generation != requestGeneration) return
        runCatching { report("Audio: focus change=$change activeTracks=${active.size}") }
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> focusVolume = DUCKED_VOLUME
            AudioManager.AUDIOFOCUS_GAIN -> { focusHeld = true; focusVolume = 1f }
            AudioManager.AUDIOFOCUS_LOSS, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                focusHeld = false; focusVolume = 0f
                if (change == AudioManager.AUDIOFOCUS_LOSS) mediaSuppressed = true
            }
        }
        applyVolumes()
    }

    @Synchronized fun acquire(track: AudioTrack, channel: AudioChannel, attributes: AudioAttributes) {
        if (closed || !enabled || manager == null) return
        active[track] = Entry(channel, attributes)
        if (channel == AudioChannel.MEDIA) mediaAttributes = attributes
        refreshRequest()
    }

    @Synchronized fun release(track: AudioTrack) {
        if (active.remove(track) != null) refreshRequest()
    }

    @Synchronized fun onMediaPlaying(playing: Boolean) {
        if (closed) return
        val wasPlaying = mediaPlaying
        mediaPlaying = playing
        // A repeated Now Playing update must not steal focus from a newly selected native source.
        if (playing && wasPlaying != true) mediaSuppressed = false
        refreshRequest()
        if (playing && wasPlaying != true && !focusHeld && requestedChannel == AudioChannel.MEDIA) requestCurrentFocus()
    }

    @Synchronized fun setMicrophones(phone: Boolean, assistant: Boolean) {
        if (closed || !enabled) return
        captures.clear()
        if (phone) addCapture(AudioChannel.PHONE, AudioAttributes.USAGE_VOICE_COMMUNICATION)
        if (assistant) addCapture(AudioChannel.ASSISTANT, AudioAttributes.USAGE_ASSISTANT)
        refreshRequest()
    }
    @Synchronized fun captureAllowed(): Boolean = !closed && (!enabled || focusHeld && !externalCall)

    private fun addCapture(channel: AudioChannel, usage: Int) {
        captures[channel] = Entry(channel, active.values.firstOrNull { it.channel == channel }?.attributes
            ?: AudioAttributes.Builder().setUsage(usage).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
    }

    @Synchronized fun setExternalCall(active: Boolean) {
        if (closed || externalCall == active) return
        externalCall = active
        if (active) abandonRequest() else refreshRequest()
        applyVolumes()
        runCatching { report("Audio: external call owns route=$active") }
    }

    @Synchronized fun onCommunicationEnded() {
        if (closed) return
        abandonRequest()
        refreshRequest()
    }

    @Synchronized override fun close() {
        if (closed) return
        closed = true
        abandonRequest()
        active.clear(); captures.clear(); mediaAttributes = null
        publishOwnership(false)
    }

    private fun abandonRequest() {
        requestGeneration++
        if (Build.VERSION.SDK_INT >= 26) request?.let { runCatching { manager?.abandonAudioFocusRequest(it) } }
        legacyListener?.let { runCatching { manager?.abandonAudioFocus(it) } }; legacyListener = null
        request = null; requestedChannel = null; focusHeld = false; focusVolume = 0f
    }

    private fun refreshRequest() {
        if (closed || !enabled || manager == null) return
        refreshExternalCall()
        if (externalCall) { applyVolumes(); return }
        val primary = (active.values + captures.values).filter {
            it.channel != AudioChannel.NAVIGATION && (it.channel != AudioChannel.MEDIA || !mediaSuppressed && mediaPlaying != false)
        }.maxByOrNull { it.channel.priority() }
            ?: mediaAttributes?.takeIf { !mediaSuppressed && mediaPlaying != false }?.let { Entry(AudioChannel.MEDIA, it) }
            ?: active.values.firstOrNull { it.channel == AudioChannel.NAVIGATION }
        if (primary == null) { abandonRequest(); applyVolumes(); return }
        if ((request != null || legacyListener != null) && requestedChannel == primary.channel) { applyVolumes(); return }
        abandonRequest()
        val generation = ++requestGeneration
        val gain = when (primary.channel) {
            AudioChannel.MEDIA -> AudioManager.AUDIOFOCUS_GAIN
            AudioChannel.PHONE, AudioChannel.RINGTONE -> AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
            AudioChannel.ASSISTANT -> AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
            AudioChannel.NAVIGATION -> if (factoryRouting) AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
                else AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
        }
        if (Build.VERSION.SDK_INT >= 26) request = AudioFocusRequest.Builder(gain).setAudioAttributes(primary.attributes)
            .setOnAudioFocusChangeListener({ change -> onFocusChanged(generation, change) }, Handler(Looper.getMainLooper())).build()
        else { legacyGain = gain; legacyListener = AudioManager.OnAudioFocusChangeListener { change -> onFocusChanged(generation, change) } }
        requestedChannel = primary.channel
        requestCurrentFocus()
    }

    private fun requestCurrentFocus() {
        refreshExternalCall()
        if (externalCall || closed) return
        val result = runCatching {
            if (Build.VERSION.SDK_INT >= 26) manager?.requestAudioFocus(request ?: return)
            else manager?.requestAudioFocus(legacyListener ?: return, AudioManager.STREAM_MUSIC, legacyGain)
        }.getOrDefault(AudioManager.AUDIOFOCUS_REQUEST_FAILED)
        focusHeld = result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        focusVolume = if (focusHeld) 1f else 0f
        applyVolumes()
        runCatching { report("Audio: focus requested channel=$requestedChannel granted=$result activeTracks=${active.size}") }
    }

    private fun refreshExternalCall() {
        // OEM HFP may disconnect its audio on focus loss, before the next route poll.
        val current = isExternalCall?.invoke() ?: return
        if (current == externalCall) return
        externalCall = current
        if (current) { abandonRequest(); applyVolumes() }
        runCatching { report("Audio: external call owns route=$current") }
    }

    private fun applyVolumes() {
        val navigation = active.values.any { it.channel == AudioChannel.NAVIGATION }
        active.forEach { (track, entry) ->
            val local = when {
                externalCall -> 0f
                entry.channel == AudioChannel.MEDIA && (mediaSuppressed || mediaPlaying == false) -> 0f
                requestedChannel in setOf(AudioChannel.PHONE, AudioChannel.ASSISTANT, AudioChannel.RINGTONE) && entry.channel != requestedChannel -> 0f
                entry.channel == AudioChannel.MEDIA && navigation -> DUCKED_VOLUME
                else -> 1f
            }
            runCatching { track.setVolume(focusVolume * local) }
        }
        // Guidance alone overlays the original source; it does not disconnect Bluetooth music.
        publishOwnership(!closed && !externalCall && focusHeld && requestedChannel != null && requestedChannel != AudioChannel.NAVIGATION)
    }

    private fun publishOwnership(value: Boolean) {
        if (ownership == value) return
        ownership = value
        runCatching { onOwnershipChanged(value) }
    }

    private fun AudioChannel.priority() = when (this) {
        AudioChannel.PHONE -> 4
        AudioChannel.RINGTONE -> 3
        AudioChannel.ASSISTANT -> 2
        AudioChannel.MEDIA -> 1
        AudioChannel.NAVIGATION -> 0
    }
    private companion object { const val DUCKED_VOLUME = 0.2f }
}
