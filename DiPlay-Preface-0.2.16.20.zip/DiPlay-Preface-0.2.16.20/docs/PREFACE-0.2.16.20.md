# preface v0.2.16.20

- 设置中可独立开启“开机自动开启车机热点”，沿用车机保存的热点名称和密码，不受 USB/无线连接选择影响。
- 按原厂接收器能力识别 E01 三指飞屏，不再按单一设备名限制；保留系统全局手势和 `Extraservice` 原厂控制链路，避免应用重复发送手势。
- 支持在 CarPlay 页面使用方向盘语音键唤起 Siri，并保留 Android 5.1 车机的麦克风回退处理。
- 安卓蓝牙连接提示明确当前模式，并可直接进入蓝牙工具核对原厂蓝牙模式。
- 下载 APK 后覆盖安装即可保留已有设置和授权信息。

本版适用于 Android 5.1 的吉利 E01 车机。开机热点、原厂三指飞屏和 Siri 语音键行为仍需在对应车机上确认；实际可用能力受车机固件影响。

## English

- Enable automatic car hotspot startup independently of USB or wireless CarPlay, using the hotspot credentials saved on the head unit.
- Improve E01 three-finger navigation projection capability detection while retaining the factory gesture path.
- Allow the steering voice key to request Siri during CarPlay, with an Android 5.1 microphone fallback.
- Clarify the current Bluetooth mode and provide a direct link to Bluetooth tools.
- Install over the existing app to retain settings and activation information.

For Geely E01 head units running Android 5.1. Hotspot startup, factory flyscreen gestures and Siri audio still depend on the head unit firmware and require vehicle verification.
