# preface v0.2.16.17

- Android 5.1 车机缺少标准 VPN 授权 Activity 时，改为打开系统 VPN 设置；返回 DiPlay 后重新校验授权，不绕过 VPN 权限。
- E01 原厂蓝牙维护接口不存在时，显示车型/固件兼容提示并建议切换安卓蓝牙，不执行维护脚本。
- 保留上一版通话音频焦点保护、蓝牙资源保护和工具页优化。

本版本不能为没有 `ExtraUtilsService` 的固件补造原厂维护接口；临时 root 仅适合诊断。原车通话界面和 HFP 服务继续保留。

## English

Android 5.1 head units without the standard VPN consent activity now open system VPN settings and recheck consent when returning to DiPlay. Missing E01 `ExtraUtilsService` support is reported as a vehicle/firmware compatibility limitation with an Android Bluetooth fallback; no maintenance script runs. Previous call-audio protection, Bluetooth asset protection and tools-page improvements remain.
