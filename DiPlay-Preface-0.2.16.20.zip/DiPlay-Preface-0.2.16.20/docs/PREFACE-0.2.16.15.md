# preface v0.2.16.15（本地候选）

- 蓝牙维护资源改为加密封装，运行前校验完整性和正式安装包身份。
- 补齐蓝牙测试、安装适配的底层授权复核，确认期间授权失效会停止操作。
- 蓝牙工具页突出当前步骤，选择手机与连接 CarPlay 并排显示，恢复选项默认折叠；停止测试时显示在上方。

Android 5.1 起可用，直接覆盖安装以保留设置和授权。加密与混淆提高分析成本，不能保证无法逆向。实车连接仍需验证。公开版本保持 0.2.16.14。

## English

Encrypted maintenance assets with integrity and package-identity checks, additional manager-level admission checks before Bluetooth tests/installation, and clearer next-step controls. Phone selection and CarPlay connection share a row; recovery actions are collapsed and stop-test controls appear near the top. Android 5.1 minimum. Packaging protection cannot guarantee resistance to reverse engineering. Local candidate; public release remains 0.2.16.14. Vehicle validation remains necessary.
