# 蓝牙保护范围与验证

0.2.16.16 本地候选对正式 `e01Licensed` APK 使用 R8 优化、类和方法改名及内联。检查范围包含蓝牙管理、原厂权限接口、手机查询、GOC 通道、切换协调、资源解密和授权验证。Android 页面入口、生命周期及 JNI 名称按运行要求保留。mapping 仅供维护者私下排错，不进入 APK 或 Release。

蓝牙维护脚本与可选 GOC 组件在构建时先压缩，再使用 AES-256-GCM 加密，随机 96 位 nonce、128 位标签，并绑定资源名及应用签名上下文。构建时生成随机 256 位主密钥，原始密钥只存于本地构建目录；运行时以拆分数据生成代码并一同参与 R8 优化，APK 不包含独立密钥文件。最终 APK 不含明文 `manage.sh` 或 ELF 兼容组件。源码中的脚本位于 `common/src/main/bluetooth/`；生成的密文只存在于 build 目录，不提交 Git。原始 GOC 输入仍由外部 `DIPLAY_GOC_ASSETS_DIR` 提供，原始 SHA-256 和第三方声明继续校验、保留。

授权版本解密前检查正式包名、签名和不可调试状态；校验标签后限制解压大小，组件再校验原始哈希。解密后的维护文件只写入应用私有目录并设为 0600，临时文件原子替换；运行组件另授予所有者执行权限。不得覆盖正在运行的维护 watchdog。恢复和只读检查不依赖有效授权；新增测试与安装在业务层和执行前复核授权，授权过期不能仅靠已打开的确认框继续操作。

**这是加密封装与混淆，不是不可逆保护。** 密钥仍须在客户端重建，拆分数据和混淆代码可被分析；客户端逻辑、源码与运行时内容也可分析，不能把它当作服务端秘密或抵御拥有 Root 权限的攻击者。运行脚本及组件需要还原到应用私有目录；系统安装的兼容组件也可被有权限的人提取。GCM 能检测内容损坏，但能恢复客户端派生规则的攻击者也能重新构造封装。真正的授权依赖服务端签名和短期租约；客户端仍可能被修改。不要宣称防破解完成或绝对安全。

## 验证

```sh
python scripts/check_bluetooth_obfuscation.py mobile/build/outputs/apk/e01Licensed/mobile-e01Licensed.apk mobile/build/outputs/mapping/e01Licensed/mapping.txt --output /private/output/bluetooth-obfuscation.json
```

检查最终 DEX 的类定义和内部方法、加密资源头、明文资源缺失、第三方声明和 mapping 未打包。还必须对最终 APK 运行 `BluetoothAssetsTest`：检查解密后脚本字节、组件哈希、错误签名、密文/标签篡改、资源替换及解压上限；再执行完整包启动认证和 API 22 lint。普通本地 `e01` 按既有要求保留不混淆。桌面检查不能代替实车验证。

## English

The licensed APK uses R8 renaming/inlining for Bluetooth and licensing business code. Maintenance assets use compressed AES-256-GCM envelopes with a locally generated random master, random nonces and signer/asset-associated context. A split runtime representation is processed by R8; no raw key file is packaged. The licensed loader checks package identity, signer and debugging flags, verifies authentication before bounded decompression and retains the original component hash. Plaintext is required in the app-private directory at runtime; active recovery scripts are preserved. Test/install admission is checked in the manager and immediately before execution, while recovery remains independent of authorization.

This is packaging protection, not a secret-key boundary: the generated client key can be recovered from code or runtime, and the client can be inspected or patched. Runtime extraction remains possible. Preserve source, attribution and licenses; keep mapping private. Verify the actual APK, decryption, tampering rejection, licensing regression, bootstrap and API 22 compatibility before delivery. Vehicle behavior still requires a vehicle test.
