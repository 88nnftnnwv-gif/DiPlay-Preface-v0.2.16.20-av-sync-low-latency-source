# preface v0.2.16.16（本地候选）

- “关于 DiPlay”补上星瑞版 GitHub 地址，保留上游鸣谢；检查更新只保留在设置概览。
- 原车通话期间，申请音频焦点前即时检查通话状态；E01 原车来电铃声阶段也保留给原车电话处理。
- 保留上一版蓝牙资源加密和工具页优化。

通话无声的实车原因仍需验证。本版没有屏蔽原车电话界面；原车蓝牙通话服务继续保留。可覆盖安装以保留设置和授权。本次发布版本为 0.2.16.16。

## English

The About page includes the Preface GitHub project and upstream credits. Update checking remains in the settings overview. Audio focus requests now recheck native-call mode immediately; factory E01 ringing is protected as well. Bluetooth asset protection and tools-page improvements are retained.

Vehicle call audio still requires verification. This candidate does not suppress the OEM phone screen or disable native HFP. This is the 0.2.16.16 release.

